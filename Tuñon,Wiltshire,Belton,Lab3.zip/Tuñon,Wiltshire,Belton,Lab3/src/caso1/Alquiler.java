package caso1;

import java.util.Scanner;

class Alquiler {
	String Consultar;
	String Reserva;
	
	public Alquiler() {
		this.Consultar = Consultar;
		this.Reserva = Reserva;
	}
	
	public String getConsultar() {
		return Consultar;
	}
	public void setConsultar(String consultar) {
		Consultar = consultar;
	}
	public String getReserva() {
		return Reserva;
	}
	public void setReserva(String reserva) {
		this.Reserva = reserva;
	}
	
public static void main(String[] args) {}
	

	public void someMethod() {
		Scanner scanner = new Scanner(System.in);
		System.out.println("CONSULTA RESERVAS");
        System.out.println("¿Tiene una reserva hecha? ");
        String consultar = scanner.nextLine();
      
        System.out.println("Ingrese su número de reserva: ");
        String reserva = scanner.nextLine();
        
        Alquiler alquiler = new Alquiler();
        alquiler.setConsultar(consultar);
        alquiler.setReserva(reserva);
        
        
        System.out.println("DATOS DE LA RESERVA ");
        System.out.println("Tiene reserva: " + alquiler.getConsultar());
        System.out.println("Telefono de contacto: " + alquiler.getReserva());
        System.out.println("Tenga buen viaje y disfrute.  " );
     
        scanner.close();
	}	
	}

	


