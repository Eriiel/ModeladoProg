package caso1;

import java.util.Scanner;

class Reservas {
    private static int contadorReservas = 1;
    private int numeroReserva;
    private String fechaInicio;
    private String fechaFin;

    public Reservas() {
        this.numeroReserva = contadorReservas++;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
    }

    public int getNumeroReserva() {
        return numeroReserva;
    }

    public String getFechaInicio() {
        return fechaInicio;
    }

    public String getFechaFin() {
        return fechaFin;
    }

    public static void main(String[] args) {}
 

	public void someMethod() {
		 Scanner scanner = new Scanner(System.in);


	        System.out.println("Ingrese la fecha de inicio de la reserva (YYYY-MM-DD): ");
	        String fechaInicio = scanner.nextLine();
	        System.out.println("Ingrese la fecha de fin de la reserva (YYYY-MM-DD): ");
	        String fechaFin = scanner.nextLine();
	        Reservas reserva1 = new Reservas();
	        System.out.println("Número de reserva: " + reserva1.getNumeroReserva());
	        System.out.println("Fecha de inicio: " + reserva1.getFechaInicio());
	        System.out.println("Fecha de fin: " + reserva1.getFechaFin());

	        scanner.close();
		
	}
}
