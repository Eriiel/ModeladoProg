package caso1;

import java.util.Scanner;

public class Yates {
	
	String nombre;
	String marca;
	int cantidadPasajeros;
	private String id;
	float tarifa;
	private static String dispo; 
	public Yates(String nombre, String marca, int cantidadPasajeros, String id, float tarifa, String dispo) {
		this.nombre = nombre;
		this.marca = marca;
		this.cantidadPasajeros = cantidadPasajeros;
		this.id = id;
		this.tarifa = tarifa;
		Yates.dispo = dispo;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getMarca() {
		return marca;
	}
	public void setMarca(String marca) {
		this.marca = marca;
	}
	public int getCantidadPasajeros() {
		return cantidadPasajeros;
	}
	public void setCantidadPasajeros(int cantidadPasajeros) {
		this.cantidadPasajeros = cantidadPasajeros;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public float getTarifa() {
		return tarifa;
	}
	public void setTarifa(float tarifa) {
		this.tarifa = tarifa;
	}
	public String getDispo() {
		return dispo;
	}
	public void setDispo(String dispo) {
		Yates.dispo = dispo;
	}
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("YATES");
        System.out.println("Ingrese el nombre del yate: ");
        String nombre = scanner.nextLine();
        System.out.println("Ingrese la marca del yate: ");
        String marca = scanner.nextLine();
        System.out.println("Ingrese la cantidad de pasajeros: ");
        int cantidadPasajeros = scanner.nextInt();
        scanner.nextLine();
        System.out.println("Ingrese id del yate: ");
        String id = scanner.nextLine();
        System.out.println("Ingrese la tarifa de alquiler por dia: ");
        float tarifa = scanner.nextFloat();
  

        Yates yate = new Yates(nombre,marca,cantidadPasajeros, id, tarifa, dispo);
        
        System.out.println("DATOS DEL YATE: ");
        System.out.println("Nombre del yate: " + yate.getNombre());
        System.out.println("Marca del yate: " + yate.getMarca());
        System.out.println("Cantidad de pasajeros: " + yate.getCantidadPasajeros());
        System.out.println("Id del yate: " + yate.getId());
        System.out.println("Tarifa de alquiler por dia: " + yate.getTarifa());
        System.out.println("Disponibilidad: " + yate.getDispo());
        scanner.close();
	}

}
