package caso1;

import java.util.Scanner;

class Reserva {
    private static int contadorReservas = 1;
    private int numeroReserva;
    private String fechaInicio;
    private String fechaFin;

    public Reserva(String fechaInicio, String fechaFin) {
        this.numeroReserva = contadorReservas++;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
    }

    // Métodos get para la información solicitada
    public int getNumeroReserva() {
        return numeroReserva;
    }

    public String getFechaInicio() {
        return fechaInicio;
    }

    public String getFechaFin() {
        return fechaFin;
    }

    // Método main para probar la clase Reserva
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Solicitar la fecha de inicio
        System.out.println("Ingrese la fecha de inicio de la reserva (YYYY-MM-DD): ");
        String fechaInicio = scanner.nextLine();

        // Solicitar la fecha de fin
        System.out.println("Ingrese la fecha de fin de la reserva (YYYY-MM-DD): ");
        String fechaFin = scanner.nextLine();

        // Crear una reserva con las fechas proporcionadas por el usuario
        Reserva reserva1 = new Reserva(fechaInicio, fechaFin);

        // Mostrar la información de la reserva
        System.out.println("Número de reserva: " + reserva1.getNumeroReserva());
        System.out.println("Fecha de inicio: " + reserva1.getFechaInicio());
        System.out.println("Fecha de fin: " + reserva1.getFechaFin());

        scanner.close();
    }
}
